namespace Memory
{
    public partial class Form1 : Form
    {
        int licznikOkien = 0;
        int pierwszeOkno = 0;
        int faktycznyTag;//Przechowywanie tagu pierwszego okna, do por�wnania z drugim
        Boolean turaGracza = true;
        int pkt1 = 0;
        int pkt2 = 0;
        PictureBox Kopia = new PictureBox();
        public Form1()
        {
            InitializeComponent();
        }
        private void pictureBox1_OnClick(object sender, EventArgs e)
        {
            PictureBox btn = sender as PictureBox;

            //Tworzenie kopii

            licznikOkien++;
            switch (btn.Tag)
            {
                case 1:
                    btn.Image = Image.FromFile("DarkAngels.jpg");
                    pierwszeOkno = 1;
                    break;
                case 2:
                    btn.Image = Image.FromFile("Alpha.jpg");
                    pierwszeOkno = 2;
                    break;
                case 3:
                    btn.Image = Image.FromFile("BlackLegion.jpg");
                    pierwszeOkno = 3;
                    break;
                case 4:
                    btn.Image = Image.FromFile("Eldar.jpg");
                    pierwszeOkno = 4;
                    break;
                case 5:
                    btn.Image = Image.FromFile("Nids.jpg");
                    pierwszeOkno = 5;
                    break;
                case 6:
                    btn.Image = Image.FromFile("ThousandSons.jpg");
                    pierwszeOkno = 6;
                    break;
                case 7:
                    btn.Image = Image.FromFile("AdeptusMech.png");
                    pierwszeOkno = 7;
                    break;
                case 8:
                    btn.Image = Image.FromFile("ImperialFist.png");
                    pierwszeOkno = 8;
                    break;
                case 9:
                    btn.Image = Image.FromFile("IronWarriors.png");
                    pierwszeOkno = 9;
                    break;
                case 10:
                    btn.Image = Image.FromFile("Nerd.png");
                    pierwszeOkno = 10;
                    break;
                case 11:
                    btn.Image = Image.FromFile("SCP.png");
                    pierwszeOkno = 11;
                    break;
                case 12:
                    btn.Image = Image.FromFile("shark.png");
                    pierwszeOkno = 12;
                    break;
            }
            if (licznikOkien == 1)
            {
                faktycznyTag = Convert.ToInt32(btn.Tag);


            }
            if (licznikOkien == 2)
            {
                if (pierwszeOkno != faktycznyTag)
                {
                    Counter();
                    btn.Image = Image.FromFile("pytajnik.png");
                    foreach (PictureBox pb in Controls.OfType<PictureBox>())
                    {
                        if (Convert.ToInt32(pb.Tag) == faktycznyTag)
                        {
                            pb.Image = Image.FromFile("pytajnik.png");
                        }
                    }
                    faktycznyTag = 0;
                    if (turaGracza == true)
                    {
                        turaGracza = false;
                        label6.Text = "Tura: " + textBox2.Text;
                    }
                    else
                    {
                        turaGracza = true;
                        label6.Text = "Tura: " + textBox1.Text;
                    }
                }
                else
                {
                    if(turaGracza == true)
                    {
                        pkt1 += 1;
                        punkty1.Text = pkt1.ToString();
                    }
                    else
                    {
                        pkt2 += 1;
                        punkty2.Text = pkt2.ToString();
                    }
                }
                licznikOkien = 0;
                

            }




        }
        private void button1_Click(object sender, EventArgs e)
        {
            
            label6.Text = "Tura: " + textBox1.Text;
            if ((numericUpDown2.Value * numericUpDown1.Value) % 2 != 0)
            {
                MessageBox.Show("Nieparzysta ilo�� kart");

            }
            else
            {
                int liczbaZdj = decimal.ToInt32(numericUpDown1.Value * numericUpDown2.Value);
                Label imie1 = new Label()
                {
                    Text = textBox1.Text + ": ",
                    Location = new Point(10, 10),
                    TabIndex = 10
                };
                Label imie2 = new Label()
                {
                    Text = textBox2.Text + ": ",
                    Location = new Point(880, 10),
                    TabIndex = 11
                };
                punkty1.Size = new Size(5, 5);
                punkty2.Size = new Size(5, 5);
                punkty1.Location = new Point(10, 30);
                punkty2.Location = new Point(880, 30);
                label1.Visible = false;
                label2.Visible = false;
                label3.Visible = false;
                label4.Visible = false;
                numericUpDown1.Visible = false;
                numericUpDown2.Visible = false;
                textBox1.Visible = false;
                textBox2.Visible = false;
                button1.Visible = false;
                Controls.Add(imie1);
                Controls.Add(imie2);
                
                int licznik = 0;
                int[] array = [];

                Random r = new Random();
                List<int> list = new List<int>();
                while (list.Count != liczbaZdj)
                {
                    int k = r.Next(1, liczbaZdj + 1);
                    if (list.Contains(k))
                        continue;
                    else
                        list.Add(k);
                }
                int index = 0;
                foreach (int cyfra in list.ToList())
                {
                    if (cyfra > liczbaZdj / 2)
                    {
                        list[index] -= liczbaZdj / 2;
                    }
                    index++;
                }

                for (int i = 0; i < numericUpDown1.Value; i++)
                {
                    for (int j = 0; j < numericUpDown2.Value; j++)
                    {

                        PictureBox pictureBox1 = new PictureBox()
                        {

                            Size = new Size(80, 80),
                            Location = new Point(200 + j * 100, 100 + i * 100),
                            Image = Image.FromFile("pytajnik.png"),
                            SizeMode = PictureBoxSizeMode.StretchImage,
                            BorderStyle = BorderStyle.Fixed3D,
                            Tag = list[licznik]
                        };
                        //array[licznik] = licznik;
                        pictureBox1.Click += pictureBox1_OnClick;
                        Controls.Add(pictureBox1);
                        licznik++;

                    }
                }
            }

        }
        private void KlikKarta(object sender, EventArgs e)
        {
            PictureBox btn = sender as PictureBox;
        }

        public static void Counter()
        {
            var timer1 = new System.Windows.Forms.Timer();
            if (1000 == 0 || 1000 < 0) return;

            // Console.WriteLine("start wait timer");
            timer1.Interval = 1000;
            timer1.Enabled = true;
            timer1.Start();

            timer1.Tick += (s, e) =>
            {
                timer1.Enabled = false;
                timer1.Stop();
                // Console.WriteLine("stop wait timer");
            };

            while (timer1.Enabled)
            {
                Application.DoEvents();
            }
        }
    }
}
//https://github.com/zurke20p/memory